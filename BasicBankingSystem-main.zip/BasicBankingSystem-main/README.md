# BasicBankingSystem
Basic Banking System is dynamic website which contain 10 users in which we can transfer amount between them. You can run the project using XAMPP server
